import { Product } from "./product.model";

export interface CartItem {
  id: number;
  product: Product;
  size: string;
  quantity: number;
  price: number;
  discountedPrice: number;
  userId: number;
}

export interface Cart {
  id: number;
  cartItems: CartItem[];
  totalPrice: number;
  totalItem: number;
  totalDiscountedPrice: number;
  discounte: number;
}